package com.saeed.simmanager.data

import androidx.room.withTransaction

/** Centralizes business rules so screens cannot create inconsistent links or overpayments. */
class AppRepository(private val db: AppDatabase) {
    suspend fun createOrder(customerId: Long, simId: Long, packageId: Long, dueDate: Long? = null, notes: String = ""): Long =
        db.withTransaction {
            val customer = db.customerDao().getById(customerId)
                ?: error("العميل غير موجود")
            val sim = db.simDao().getById(simId)
                ?: error("الشريحة غير موجودة")
            val packagePlan = db.packageDao().getById(packageId)
                ?: error("الباقة غير موجودة")

            require(sim.customerId == customer.id) { "الشريحة لا تتبع هذا العميل" }
            require(sim.providerId == packagePlan.providerId) { "شركة الباقة لا تطابق شركة الشريحة" }
            require(sim.custodyStatus == "with_me") { "الشريحة ليست في عهدتك حاليًا" }
            require(packagePlan.active) { "هذه الباقة غير متاحة" }

            val id = db.orderDao().insert(
                ServiceOrder(
                    customerId = customerId,
                    simId = simId,
                    packageId = packageId,
                    packageNameSnapshot = packagePlan.name,
                    priceYER = packagePlan.priceYER,
                    dueDate = dueDate,
                    notes = notes
                )
            )
            db.activityLogDao().insert(
                ActivityLog("order", id, "created", "إنشاء طلب ${packagePlan.name}")
            )
            if (dueDate != null) {
                db.reminderDao().insert(
                    Reminder(customerId = customerId, orderId = id, reminderType = "payment_due", remindAt = dueDate, note = "موعد السداد المتوقع")
                )
            }
            id
        }

    suspend fun recordPayment(orderId: Long, amountYER: Long, method: String, notes: String = ""): Long =
        db.withTransaction {
            require(amountYER > 0) { "أدخل مبلغًا أكبر من صفر" }
            val order = db.orderDao().getById(orderId) ?: error("الطلب غير موجود")
            require(order.status != "cancelled") { "لا يمكن تسجيل دفعة لطلب ملغي" }
            val alreadyPaid = db.paymentDao().sumForOrder(orderId)
            val remaining = order.priceYER - alreadyPaid
            require(amountYER <= remaining) { "المبلغ أكبر من المتبقي (${remaining} ريال)" }

            val paymentId = db.paymentDao().insert(
                Payment(orderId = orderId, amountYER = amountYER, method = method, notes = notes)
            )
            db.activityLogDao().insert(
                ActivityLog("payment", paymentId, "created", "دفعة ${amountYER} ريال للطلب #$orderId")
            )
            paymentId
        }

    suspend fun changeOrderStatus(orderId: Long, status: String) = db.withTransaction {
        require(status in setOf("new", "processing", "completed", "cancelled"))
        val order = db.orderDao().getById(orderId) ?: error("الطلب غير موجود")
        require(order.status != "cancelled" || status == "cancelled") { "لا يمكن إعادة فتح طلب ملغي من هذه الشاشة" }
        val now = if (status == "completed") System.currentTimeMillis() else null
        db.orderDao().updateStatus(orderId, status, now)
        db.activityLogDao().insert(ActivityLog("order", orderId, "status_changed", status))
    }


    suspend fun registerSim(customerId: Long, providerId: Long, number: String): Long = db.withTransaction {
        require(db.customerDao().getById(customerId) != null) { "العميل غير موجود" }
        require(db.providerDao().getById(providerId) != null) { "شركة الاتصالات غير موجودة" }
        val simId = db.simDao().insert(SimCard(customerId = customerId, providerId = providerId, number = number.trim()))
        db.handoverDao().insert(SimHandoverEvent(simId = simId, action = "received"))
        db.activityLogDao().insert(ActivityLog("sim", simId, "received", "استلام شريحة من العميل"))
        simId
    }

    suspend fun receiveSimAgain(simId: Long) = db.withTransaction {
        val sim = db.simDao().getById(simId) ?: error("الشريحة غير موجودة")
        require(sim.custodyStatus == "returned") { "الشريحة موجودة لديك بالفعل" }
        db.simDao().updateCustody(simId, "with_me")
        db.handoverDao().insert(SimHandoverEvent(simId, "received", notes = "استلام الشريحة مرة أخرى"))
        db.activityLogDao().insert(ActivityLog("sim", simId, "received_again", "استلام الشريحة مرة أخرى من العميل"))
    }

    suspend fun returnSimToCustomer(simId: Long) = db.withTransaction {
        val sim = db.simDao().getById(simId) ?: error("الشريحة غير موجودة")
        require(sim.custodyStatus == "with_me") { "الشريحة مسجلة بالفعل على أنها سُلّمت" }
        db.simDao().updateCustody(simId, "returned")
        db.handoverDao().insert(SimHandoverEvent(simId, "returned"))
        db.activityLogDao().insert(ActivityLog("sim", simId, "returned", "تسليم الشريحة للعميل"))
    }
}
