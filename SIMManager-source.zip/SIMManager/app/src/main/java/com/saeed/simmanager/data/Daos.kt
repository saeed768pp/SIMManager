package com.saeed.simmanager.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface CustomerDao {
    @Query("SELECT * FROM customers WHERE archived = 0 ORDER BY name COLLATE NOCASE")
    fun observeAll(): Flow<List<Customer>>

    @Query("SELECT * FROM customers WHERE id = :id LIMIT 1")
    suspend fun getById(id: Long): Customer?

    @Insert(onConflict = OnConflictStrategy.ABORT)
    suspend fun insert(customer: Customer): Long

    @Query("UPDATE customers SET archived = 1 WHERE id = :id")
    suspend fun archive(id: Long)
}

@Dao
interface ProviderDao {
    @Query("SELECT * FROM telecom_providers WHERE active = 1 ORDER BY name COLLATE NOCASE")
    fun observeAll(): Flow<List<TelecomProvider>>

    @Query("SELECT * FROM telecom_providers WHERE id = :id LIMIT 1")
    suspend fun getById(id: Long): TelecomProvider?

    @Insert(onConflict = OnConflictStrategy.ABORT)
    suspend fun insert(provider: TelecomProvider): Long
}

@Dao
interface PackageDao {
    @Query("SELECT * FROM packages WHERE active = 1 ORDER BY name COLLATE NOCASE")
    fun observeAll(): Flow<List<PackagePlan>>

    @Query("SELECT * FROM packages WHERE id = :id LIMIT 1")
    suspend fun getById(id: Long): PackagePlan?

    @Insert(onConflict = OnConflictStrategy.ABORT)
    suspend fun insert(packagePlan: PackagePlan): Long
}

@Dao
interface SimDao {
    @Query("SELECT * FROM sim_cards WHERE active = 1 ORDER BY receivedAt DESC")
    fun observeAll(): Flow<List<SimCard>>

    @Query("SELECT * FROM sim_cards WHERE id = :id LIMIT 1")
    suspend fun getById(id: Long): SimCard?

    @Insert(onConflict = OnConflictStrategy.ABORT)
    suspend fun insert(simCard: SimCard): Long

    @Query("UPDATE sim_cards SET custodyStatus = :status WHERE id = :id")
    suspend fun updateCustody(id: Long, status: String)
}

@Dao
interface OrderDao {
    @Query("""
        SELECT o.id AS id,
               c.name AS customerName,
               s.number AS simNumber,
               o.packageNameSnapshot AS packageNameSnapshot,
               o.priceYER AS priceYER,
               COALESCE(SUM(p.amountYER), 0) AS paidYER,
               o.status AS status,
               s.custodyStatus AS custodyStatus,
               o.createdAt AS createdAt,
               o.dueDate AS dueDate
        FROM orders o
        INNER JOIN customers c ON c.id = o.customerId
        INNER JOIN sim_cards s ON s.id = o.simId
        LEFT JOIN payments p ON p.orderId = o.id
        GROUP BY o.id
        ORDER BY o.createdAt DESC
    """)
    fun observeSummaries(): Flow<List<OrderSummary>>

    @Query("SELECT * FROM orders WHERE id = :id LIMIT 1")
    suspend fun getById(id: Long): ServiceOrder?

    @Insert(onConflict = OnConflictStrategy.ABORT)
    suspend fun insert(order: ServiceOrder): Long

    @Query("UPDATE orders SET status = :status, completedAt = :completedAt WHERE id = :id")
    suspend fun updateStatus(id: Long, status: String, completedAt: Long?)
}

@Dao
interface PaymentDao {
    @Query("SELECT * FROM payments ORDER BY paidAt DESC")
    fun observeAll(): Flow<List<Payment>>

    @Query("SELECT COALESCE(SUM(amountYER), 0) FROM payments WHERE orderId = :orderId")
    suspend fun sumForOrder(orderId: Long): Long

    @Query("SELECT COALESCE(SUM(amountYER), 0) FROM payments")
    fun observeTotalReceived(): Flow<Long>

    @Insert(onConflict = OnConflictStrategy.ABORT)
    suspend fun insert(payment: Payment): Long
}

@Dao
interface HandoverDao {
    @Insert(onConflict = OnConflictStrategy.ABORT)
    suspend fun insert(event: SimHandoverEvent): Long
}

@Dao
interface ActivityLogDao {
    @Insert(onConflict = OnConflictStrategy.ABORT)
    suspend fun insert(log: ActivityLog): Long
}

@Dao
interface ReminderDao {
    @Query("SELECT * FROM reminders WHERE completed = 0 ORDER BY remindAt")
    fun observePending(): Flow<List<Reminder>>

    @Insert(onConflict = OnConflictStrategy.ABORT)
    suspend fun insert(reminder: Reminder): Long

    @Query("UPDATE reminders SET completed = 1 WHERE id = :id")
    suspend fun complete(id: Long)
}
