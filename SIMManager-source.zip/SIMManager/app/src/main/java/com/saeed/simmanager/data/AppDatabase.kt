package com.saeed.simmanager.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(
    entities = [
        Customer::class,
        TelecomProvider::class,
        PackagePlan::class,
        SimCard::class,
        ServiceOrder::class,
        Payment::class,
        SimHandoverEvent::class,
        ActivityLog::class,
        Reminder::class
    ],
    version = 1,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun customerDao(): CustomerDao
    abstract fun providerDao(): ProviderDao
    abstract fun packageDao(): PackageDao
    abstract fun simDao(): SimDao
    abstract fun orderDao(): OrderDao
    abstract fun paymentDao(): PaymentDao
    abstract fun handoverDao(): HandoverDao
    abstract fun activityLogDao(): ActivityLogDao
    abstract fun reminderDao(): ReminderDao

    companion object {
        @Volatile private var INSTANCE: AppDatabase? = null

        fun getInstance(context: Context): AppDatabase = INSTANCE ?: synchronized(this) {
            INSTANCE ?: Room.databaseBuilder(
                context.applicationContext,
                AppDatabase::class.java,
                "sim_manager.db"
            ).build().also { INSTANCE = it }
        }
    }
}
