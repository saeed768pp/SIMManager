package com.saeed.simmanager.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountBalanceWallet
import androidx.compose.material.icons.filled.Assignment
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.People
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.SimCard
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import com.saeed.simmanager.data.AppDatabase
import com.saeed.simmanager.data.AppRepository
import com.saeed.simmanager.data.Customer
import com.saeed.simmanager.data.PackagePlan
import com.saeed.simmanager.data.SimCard
import com.saeed.simmanager.data.TelecomProvider
import com.saeed.simmanager.data.OrderSummary
import kotlinx.coroutines.launch
import java.time.LocalDate
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.util.Date
import java.util.Locale
import java.text.SimpleDateFormat

private enum class AppTab(val title: String, val icon: ImageVector) {
    HOME("الرئيسية", Icons.Default.Home),
    CUSTOMERS("العملاء", Icons.Default.People),
    SIMS("الشرائح", Icons.Default.SimCard),
    ORDERS("الطلبات", Icons.Default.Assignment),
    ACCOUNTS("الحسابات", Icons.Default.AccountBalanceWallet),
    SETTINGS("الإعدادات", Icons.Default.Settings)
}

private enum class AppDialog { CUSTOMER, PROVIDER, PACKAGE, SIM, ORDER, PAYMENT }

@Composable
fun SIMManagerApp(db: AppDatabase) {
    androidx.compose.runtime.CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        val customers by db.customerDao().observeAll().collectAsState(initial = emptyList())
        val providers by db.providerDao().observeAll().collectAsState(initial = emptyList())
        val packages by db.packageDao().observeAll().collectAsState(initial = emptyList())
        val sims by db.simDao().observeAll().collectAsState(initial = emptyList())
        val orders by db.orderDao().observeSummaries().collectAsState(initial = emptyList())
        val totalReceived by db.paymentDao().observeTotalReceived().collectAsState(initial = 0L)

        var selectedTab by remember { mutableStateOf(AppTab.HOME) }
        var activeDialog by remember { mutableStateOf<AppDialog?>(null) }
        var paymentOrderId by remember { mutableLongStateOf(0L) }
        val snackbarState = remember { SnackbarHostState() }
        val scope = rememberCoroutineScope()
        val repository = remember(db) { AppRepository(db) }

        fun perform(action: suspend () -> Unit) {
            scope.launch {
                try {
                    action()
                    snackbarState.showSnackbar("تم الحفظ بنجاح")
                } catch (error: Exception) {
                    snackbarState.showSnackbar(error.message ?: "حدث خطأ أثناء العملية")
                }
            }
        }

        val fabAction: (() -> Unit)? = when (selectedTab) {
            AppTab.CUSTOMERS -> ({ activeDialog = AppDialog.CUSTOMER })
            AppTab.SIMS -> ({ activeDialog = AppDialog.SIM })
            AppTab.ORDERS -> ({ activeDialog = AppDialog.ORDER })
            AppTab.SETTINGS -> ({ activeDialog = AppDialog.PROVIDER })
            else -> null
        }

        Scaffold(
            snackbarHost = { SnackbarHost(snackbarState) },
            topBar = {
                Surface(color = MaterialTheme.colorScheme.surface, shadowElevation = 2.dp) {
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 15.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text("SIM Manager", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                            Text(selectedTab.title, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        Surface(color = MaterialTheme.colorScheme.primaryContainer, shape = RoundedCornerShape(14.dp)) {
                            Icon(Icons.Default.SimCard, contentDescription = null, modifier = Modifier.padding(10.dp), tint = MaterialTheme.colorScheme.primary)
                        }
                    }
                }
            },
            bottomBar = {
                NavigationBar {
                    AppTab.values().forEach { tab ->
                        NavigationBarItem(
                            selected = selectedTab == tab,
                            onClick = { selectedTab = tab },
                            icon = { Icon(tab.icon, contentDescription = tab.title) },
                            label = { Text(tab.title, maxLines = 1) }
                        )
                    }
                }
            },
            floatingActionButton = {
                if (fabAction != null) {
                    FloatingActionButton(onClick = fabAction) {
                        Text("+", style = MaterialTheme.typography.headlineMedium)
                    }
                }
            }
        ) { innerPadding ->
            Box(Modifier.fillMaxSize().padding(innerPadding)) {
                when (selectedTab) {
                    AppTab.HOME -> DashboardScreen(customers.size, sims, orders, totalReceived)
                    AppTab.CUSTOMERS -> CustomersScreen(customers)
                    AppTab.SIMS -> SimsScreen(
                        sims, customers, providers,
                        onReceiveAgain = { id -> perform { repository.receiveSimAgain(id) } }
                    )
                    AppTab.ORDERS -> OrdersScreen(
                        orders = orders,
                        onAddPayment = { paymentOrderId = it; activeDialog = AppDialog.PAYMENT },
                        onStart = { id -> perform { repository.changeOrderStatus(id, "processing") } },
                        onComplete = { id -> perform { repository.changeOrderStatus(id, "completed") } },
                        onReturnSim = { id -> perform { repository.returnSimToCustomer(id) } }
                    )
                    AppTab.ACCOUNTS -> AccountsScreen(orders, totalReceived)
                    AppTab.SETTINGS -> SettingsScreen(providers, packages, onAddPackage = { activeDialog = AppDialog.PACKAGE })
                }
            }
        }

        when (activeDialog) {
            AppDialog.CUSTOMER -> AddCustomerDialog(
                onDismiss = { activeDialog = null },
                onSave = { name, phone, notes ->
                    activeDialog = null
                    perform { db.customerDao().insert(Customer(name = name, phone = phone, notes = notes)) }
                }
            )
            AppDialog.PROVIDER -> AddProviderDialog(
                onDismiss = { activeDialog = null },
                onSave = { name ->
                    activeDialog = null
                    perform { db.providerDao().insert(TelecomProvider(name = name)) }
                }
            )
            AppDialog.PACKAGE -> AddPackageDialog(
                providers = providers,
                onDismiss = { activeDialog = null },
                onSave = { providerId, name, price, duration ->
                    activeDialog = null
                    perform { db.packageDao().insert(PackagePlan(providerId = providerId, name = name, priceYER = price, durationDays = duration)) }
                }
            )
            AppDialog.SIM -> AddSimDialog(
                customers = customers,
                providers = providers,
                onDismiss = { activeDialog = null },
                onSave = { customerId, providerId, number ->
                    activeDialog = null
                    perform { repository.registerSim(customerId, providerId, number) }
                }
            )
            AppDialog.ORDER -> AddOrderDialog(
                customers = customers,
                sims = sims,
                packages = packages,
                onDismiss = { activeDialog = null },
                onSave = { customerId, simId, packageId, dueDate ->
                    activeDialog = null
                    perform { repository.createOrder(customerId, simId, packageId, dueDate) }
                }
            )
            AppDialog.PAYMENT -> AddPaymentDialog(
                onDismiss = { activeDialog = null },
                onSave = { amount, method, notes ->
                    val orderId = paymentOrderId
                    activeDialog = null
                    perform { repository.recordPayment(orderId, amount, method, notes) }
                }
            )
            null -> Unit
        }
    }
}

@Composable
private fun DashboardScreen(customerCount: Int, sims: List<SimCard>, orders: List<OrderSummary>, totalReceived: Long) {
    val heldSims = sims.count { it.custodyStatus == "with_me" }
    val pendingOrders = orders.count { it.status == "new" || it.status == "processing" }
    val remaining = orders.sumOf { it.remainingYER }
    val startOfToday = LocalDate.now(ZoneId.systemDefault()).atStartOfDay(ZoneId.systemDefault()).toInstant().toEpochMilli()
    val overdueCount = orders.count { it.remainingYER > 0 && it.dueDate != null && it.dueDate < startOfToday }
    LazyColumn(
        modifier = Modifier.fillMaxSize().padding(horizontal = 16.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Text("ملخص العمل", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
            Text("نظرة سريعة على العملاء والشرائح والحسابات", color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                StatCard("العملاء", customerCount.toString(), "أشخاص مسجلون", Modifier.weight(1f))
                StatCard("الشرائح لديك", heldSims.toString(), "تحت عهدتك", Modifier.weight(1f))
            }
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                StatCard("طلبات مفتوحة", pendingOrders.toString(), "جديد أو قيد التنفيذ", Modifier.weight(1f))
                StatCard("المستحقات", formatYER(remaining), "لم تُحصّل بعد", Modifier.weight(1f))
            }
        }
        item {
            Card(colors = CardDefaults.cardColors(containerColor = if (overdueCount > 0) MaterialTheme.colorScheme.errorContainer else MaterialTheme.colorScheme.surfaceVariant)) {
                Column(Modifier.fillMaxWidth().padding(14.dp)) {
                    Text("مواعيد سداد متأخرة", fontWeight = FontWeight.SemiBold)
                    Text("$overdueCount طلبًا تجاوز موعد سداده وما زال عليه مبلغ", style = MaterialTheme.typography.bodySmall)
                }
            }
        }
        item {
            Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)) {
                Column(Modifier.fillMaxWidth().padding(18.dp)) {
                    Text("إجمالي المبالغ المستلمة", color = MaterialTheme.colorScheme.onPrimaryContainer)
                    Spacer(Modifier.height(7.dp))
                    Text(formatYER(totalReceived), style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onPrimaryContainer)
                    Text("ريال يمني", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onPrimaryContainer)
                }
            }
        }
        item {
            Text("آخر الطلبات", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        }
        if (orders.isEmpty()) {
            item { EmptyCard("لا توجد طلبات بعد", "أضف عميلًا وشريحة وباقة، ثم أنشئ أول طلب.") }
        } else {
            items(orders.take(5), key = { it.id }) { OrderCompactCard(it) }
        }
        item { Spacer(Modifier.height(12.dp)) }
    }
}

@Composable
private fun StatCard(title: String, value: String, subtitle: String, modifier: Modifier = Modifier) {
    Card(modifier = modifier, colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
        Column(Modifier.fillMaxWidth().padding(14.dp)) {
            Text(title, color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodyMedium)
            Spacer(Modifier.height(7.dp))
            Text(value, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
            Text(subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@Composable
private fun CustomersScreen(customers: List<Customer>) {
    if (customers.isEmpty()) {
        EmptyScreen("لا يوجد عملاء", "اضغط زر + لإضافة أول عميل.")
    } else {
        LazyColumn(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            item { Text("قائمة العملاء (${customers.size})", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold) }
            items(customers, key = { it.id }) { customer ->
                Card {
                    Column(Modifier.fillMaxWidth().padding(15.dp)) {
                        Text(customer.name, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                        if (customer.phone.isNotBlank()) Text(customer.phone, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        if (customer.notes.isNotBlank()) Text(customer.notes, style = MaterialTheme.typography.bodySmall)
                    }
                }
            }
        }
    }
}

@Composable
private fun SimsScreen(sims: List<SimCard>, customers: List<Customer>, providers: List<TelecomProvider>, onReceiveAgain: (Long) -> Unit) {
    if (sims.isEmpty()) {
        EmptyScreen("لا توجد شرائح", "أضف شريحة بعد استلامها من العميل.")
    } else {
        LazyColumn(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            item { Text("الشرائح المسجلة (${sims.size})", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold) }
            items(sims, key = { it.id }) { sim ->
                val owner = customers.firstOrNull { it.id == sim.customerId }?.name ?: "عميل غير معروف"
                val network = providers.firstOrNull { it.id == sim.providerId }?.name ?: "شبكة غير معروفة"
                Card {
                    Column(Modifier.fillMaxWidth().padding(15.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                        Text(sim.number, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                        Text("المالك: $owner")
                        Text("الشركة: $network", color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Text(if (sim.custodyStatus == "with_me") "الشريحة في عهدتك" else "تم تسليم الشريحة", color = if (sim.custodyStatus == "with_me") MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.secondary)
                        if (sim.custodyStatus == "returned") {
                            OutlinedButton(onClick = { onReceiveAgain(sim.id) }) { Text("استلام الشريحة مجددًا") }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun OrdersScreen(
    orders: List<OrderSummary>,
    onAddPayment: (Long) -> Unit,
    onStart: (Long) -> Unit,
    onComplete: (Long) -> Unit,
    onReturnSim: (Long) -> Unit
) {
    if (orders.isEmpty()) {
        EmptyScreen("لا توجد طلبات", "أنشئ طلبًا لربط عميل بشريحته وباقته.")
    } else {
        LazyColumn(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            item { Text("كل الطلبات (${orders.size})", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold) }
            items(orders, key = { it.id }) { order ->
                Card {
                    Column(Modifier.fillMaxWidth().padding(14.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                            Text("طلب #${order.id}", fontWeight = FontWeight.Bold)
                            StatusPill(order.status)
                        }
                        Text(order.customerName, style = MaterialTheme.typography.titleMedium)
                        Text("الشريحة: ${order.simNumber}")
                        Text("الباقة: ${order.packageName}")
                        order.dueDate?.let { Text("موعد السداد المتوقع: ${formatDate(it)}", color = MaterialTheme.colorScheme.onSurfaceVariant) }
                        HorizontalDivider()
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("القيمة: ${formatYER(order.priceYER)}")
                            Text("المتبقي: ${formatYER(order.remainingYER)}", color = if (order.remainingYER > 0) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.primary, fontWeight = FontWeight.SemiBold)
                        }
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            if (order.remainingYER > 0 && order.status != "cancelled") {
                                OutlinedButton(onClick = { onAddPayment(order.id) }) { Text("تسجيل دفعة") }
                            }
                            when (order.status) {
                                "new" -> Button(onClick = { onStart(order.id) }) { Text("بدء التنفيذ") }
                                "processing" -> Button(onClick = { onComplete(order.id) }) { Text("تم التنفيذ") }
                            }
                            if (order.status == "completed" && order.custodyStatus == "with_me") {
                                OutlinedButton(onClick = { onReturnSim(order.id) }) { Text("تسليم الشريحة") }
                            }
                        }
                        Text(if (order.custodyStatus == "with_me") "الشريحة ما زالت لديك" else "الشريحة سُلّمت للعميل", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }
        }
    }
}

@Composable
private fun AccountsScreen(orders: List<OrderSummary>, totalReceived: Long) {
    val outstanding = orders.sumOf { it.remainingYER }
    LazyColumn(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item {
            Text("الحسابات", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                StatCard("المستلم", formatYER(totalReceived), "كل الدفعات", Modifier.weight(1f))
                StatCard("المتبقي", formatYER(outstanding), "على الطلبات", Modifier.weight(1f))
            }
        }
        item { Text("كشف الطلبات", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold) }
        items(orders, key = { it.id }) { order ->
            Card {
                Column(Modifier.fillMaxWidth().padding(14.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text("${order.customerName} · ${order.packageName}", fontWeight = FontWeight.SemiBold)
                    Text("قيمة الطلب: ${formatYER(order.priceYER)}")
                    Text("المدفوع: ${formatYER(order.paidYER)}", color = MaterialTheme.colorScheme.primary)
                    Text("المتبقي: ${formatYER(order.remainingYER)}", color = if (order.remainingYER > 0) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.secondary)
                    order.dueDate?.let { Text("موعد السداد المتوقع: ${formatDate(it)}", style = MaterialTheme.typography.bodySmall) }
                }
            }
        }
    }
}

@Composable
private fun SettingsScreen(providers: List<TelecomProvider>, packages: List<PackagePlan>, onAddPackage: () -> Unit) {
    LazyColumn(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item { Text("الإعدادات والبيانات الأساسية", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold) }
        item {
            Card {
                Column(Modifier.fillMaxWidth().padding(14.dp)) {
                    Text("شركات الاتصالات", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    if (providers.isEmpty()) Text("لم تضف أي شركة بعد.", color = MaterialTheme.colorScheme.onSurfaceVariant)
                    providers.forEach { Text("• ${it.name}", modifier = Modifier.padding(top = 6.dp)) }
                    if (providers.isEmpty()) Text("أضف شركة من زر + في الأسفل.", style = MaterialTheme.typography.bodySmall)
                }
            }
        }
        item {
            Card {
                Column(Modifier.fillMaxWidth().padding(14.dp)) {
                    Text("الباقات المسجلة (${packages.size})", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    if (packages.isEmpty()) {
                        Text("لا توجد باقات مسجلة بعد.", color = MaterialTheme.colorScheme.onSurfaceVariant)
                    } else {
                        packages.forEach { plan ->
                            val providerName = providers.firstOrNull { it.id == plan.providerId }?.name ?: "شركة غير معروفة"
                            Text("${plan.name} · ${formatYER(plan.priceYER)} · $providerName", modifier = Modifier.padding(top = 7.dp))
                        }
                    }
                    Spacer(Modifier.height(8.dp))
                    Button(onClick = onAddPackage, enabled = providers.isNotEmpty()) { Text("إضافة باقة") }
                    if (providers.isEmpty()) Text("أضف شركة اتصالات أولًا حتى تتمكن من إضافة الباقات.", color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
                }
            }
        }
        item {
            Card {
                Column(Modifier.fillMaxWidth().padding(14.dp)) {
                    Text("معلومات التطبيق", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    Text("نسخة أولية 1.0.0 · تخزين محلي على هذا الجهاز · لا يتطلب اتصالًا بالإنترنت.")
                }
            }
        }
    }
}

@Composable
private fun OrderCompactCard(order: OrderSummary) {
    Card {
        Column(Modifier.fillMaxWidth().padding(13.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("#${order.id} · ${order.customerName}", fontWeight = FontWeight.SemiBold)
                StatusPill(order.status)
            }
            Text("${order.packageName} · ${formatYER(order.priceYER)}")
            Text("المتبقي: ${formatYER(order.remainingYER)}", color = if (order.remainingYER > 0) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.primary)
        }
    }
}

@Composable
private fun StatusPill(status: String) {
    val label = when (status) {
        "new" -> "جديد"
        "processing" -> "قيد التنفيذ"
        "completed" -> "منفذ"
        "cancelled" -> "ملغي"
        else -> status
    }
    Surface(color = MaterialTheme.colorScheme.secondaryContainer, shape = RoundedCornerShape(20.dp)) {
        Text(label, modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp), style = MaterialTheme.typography.labelMedium)
    }
}

@Composable
private fun EmptyScreen(title: String, message: String) {
    Box(Modifier.fillMaxSize().padding(28.dp), contentAlignment = Alignment.Center) {
        EmptyCard(title, message)
    }
}

@Composable
private fun EmptyCard(title: String, message: String) {
    Card(modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.fillMaxWidth().padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Icon(Icons.Default.SimCard, contentDescription = null, modifier = Modifier.size(38.dp), tint = MaterialTheme.colorScheme.primary)
            Text(title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            Text(message, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@Composable
private fun AddCustomerDialog(onDismiss: () -> Unit, onSave: (String, String, String) -> Unit) {
    var name by remember { mutableStateOf("") }
    var phone by remember { mutableStateOf("") }
    var notes by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("إضافة عميل") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(name, { name = it }, label = { Text("اسم العميل *") }, singleLine = true)
                OutlinedTextField(phone, { phone = it }, label = { Text("رقم الهاتف") }, singleLine = true, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone))
                OutlinedTextField(notes, { notes = it }, label = { Text("ملاحظات") })
            }
        },
        confirmButton = { Button(onClick = { if (name.isNotBlank()) onSave(name.trim(), phone.trim(), notes.trim()) }, enabled = name.isNotBlank()) { Text("حفظ") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("إلغاء") } }
    )
}

@Composable
private fun AddProviderDialog(onDismiss: () -> Unit, onSave: (String) -> Unit) {
    var name by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("إضافة شركة اتصالات") },
        text = { OutlinedTextField(name, { name = it }, label = { Text("اسم الشركة") }, singleLine = true) },
        confirmButton = { Button(onClick = { if (name.isNotBlank()) onSave(name.trim()) }, enabled = name.isNotBlank()) { Text("حفظ") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("إلغاء") } }
    )
}

@Composable
private fun AddPackageDialog(providers: List<TelecomProvider>, onDismiss: () -> Unit, onSave: (Long, String, Long, Int?) -> Unit) {
    var providerId by remember { mutableLongStateOf(providers.firstOrNull()?.id ?: 0L) }
    var name by remember { mutableStateOf("") }
    var price by remember { mutableStateOf("") }
    var duration by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("إضافة باقة") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                EntityDropdown("شركة الاتصالات", providers.map { it.id to it.name }, providerId) { providerId = it }
                OutlinedTextField(name, { name = it }, label = { Text("اسم الباقة") }, singleLine = true)
                OutlinedTextField(price, { price = it }, label = { Text("السعر بالريال اليمني") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), singleLine = true)
                OutlinedTextField(duration, { duration = it }, label = { Text("المدة بالأيام (اختياري)") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), singleLine = true)
            }
        },
        confirmButton = {
            Button(onClick = { val parsed = price.toLongOrNull(); if (providerId > 0 && name.isNotBlank() && parsed != null && parsed >= 0) onSave(providerId, name.trim(), parsed, duration.toIntOrNull()) }, enabled = providerId > 0 && name.isNotBlank() && (price.toLongOrNull() ?: -1) >= 0) { Text("حفظ") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("إلغاء") } }
    )
}

@Composable
private fun AddSimDialog(customers: List<Customer>, providers: List<TelecomProvider>, onDismiss: () -> Unit, onSave: (Long, Long, String) -> Unit) {
    var customerId by remember { mutableLongStateOf(customers.firstOrNull()?.id ?: 0L) }
    var providerId by remember { mutableLongStateOf(providers.firstOrNull()?.id ?: 0L) }
    var number by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("تسجيل شريحة مستلمة") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                EntityDropdown("العميل", customers.map { it.id to it.name }, customerId) { customerId = it }
                EntityDropdown("شركة الاتصالات", providers.map { it.id to it.name }, providerId) { providerId = it }
                OutlinedTextField(number, { number = it }, label = { Text("رقم الشريحة") }, singleLine = true, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone))
            }
        },
        confirmButton = { Button(onClick = { if (customerId > 0 && providerId > 0 && number.isNotBlank()) onSave(customerId, providerId, number.trim()) }, enabled = customerId > 0 && providerId > 0 && number.isNotBlank()) { Text("حفظ الشريحة") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("إلغاء") } }
    )
}

@Composable
private fun AddOrderDialog(customers: List<Customer>, sims: List<SimCard>, packages: List<PackagePlan>, onDismiss: () -> Unit, onSave: (Long, Long, Long, Long?) -> Unit) {
    var customerId by remember { mutableLongStateOf(customers.firstOrNull()?.id ?: 0L) }
    val customerSims = sims.filter { it.customerId == customerId && it.custodyStatus == "with_me" }
    var simId by remember { mutableLongStateOf(customerSims.firstOrNull()?.id ?: 0L) }
    val selectedSim = customerSims.firstOrNull { it.id == simId } ?: customerSims.firstOrNull()
    val availablePackages = packages.filter { selectedSim != null && it.providerId == selectedSim.providerId }
    var packageId by remember { mutableLongStateOf(availablePackages.firstOrNull()?.id ?: 0L) }
    var dueDateText by remember { mutableStateOf("") }
    val parsedDueDate = remember(dueDateText) {
        if (dueDateText.isBlank()) null else runCatching {
            LocalDate.parse(dueDateText.trim(), DateTimeFormatter.ISO_LOCAL_DATE)
                .atStartOfDay(ZoneId.systemDefault()).toInstant().toEpochMilli()
        }.getOrNull()
    }
    val dueDateValid = dueDateText.isBlank() || parsedDueDate != null
    LaunchedEffect(selectedSim?.id) {
        packageId = availablePackages.firstOrNull()?.id ?: 0L
    }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("طلب باقة جديد") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                EntityDropdown("العميل", customers.map { it.id to it.name }, customerId) {
                    customerId = it
                    simId = sims.firstOrNull { sim -> sim.customerId == it && sim.custodyStatus == "with_me" }?.id ?: 0L
                }
                EntityDropdown("الشريحة", customerSims.map { it.id to it.number }, simId) { simId = it }
                EntityDropdown("الباقة", availablePackages.map { it.id to "${it.name} · ${formatYER(it.priceYER)}" }, packageId) { packageId = it }
                OutlinedTextField(
                    dueDateText,
                    { dueDateText = it },
                    label = { Text("موعد السداد المتوقع (اختياري)") },
                    placeholder = { Text("2026-12-01") },
                    singleLine = true,
                    isError = !dueDateValid
                )
                if (!dueDateValid) Text("اكتب التاريخ بصيغة سنة-شهر-يوم، مثال 2026-12-01", color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
                if (customerSims.isEmpty()) Text("لا توجد شريحة لهذا العميل في عهدتك.", color = MaterialTheme.colorScheme.error)
                else if (availablePackages.isEmpty()) Text("لا توجد باقات مسجلة لشركة هذه الشريحة.", color = MaterialTheme.colorScheme.error)
            }
        },
        confirmButton = { Button(onClick = { if (customerId > 0 && simId > 0 && packageId > 0 && dueDateValid) onSave(customerId, simId, packageId, parsedDueDate) }, enabled = customerId > 0 && simId > 0 && packageId > 0 && dueDateValid) { Text("إنشاء الطلب") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("إلغاء") } }
    )
}

@Composable
private fun AddPaymentDialog(onDismiss: () -> Unit, onSave: (Long, String, String) -> Unit) {
    var amount by remember { mutableStateOf("") }
    var method by remember { mutableStateOf("نقدًا") }
    var notes by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("تسجيل دفعة") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(amount, { amount = it }, label = { Text("المبلغ بالريال اليمني") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), singleLine = true)
                OutlinedTextField(method, { method = it }, label = { Text("طريقة الدفع") }, singleLine = true)
                OutlinedTextField(notes, { notes = it }, label = { Text("ملاحظات") })
            }
        },
        confirmButton = { Button(onClick = { amount.toLongOrNull()?.let { if (it > 0) onSave(it, method, notes) } }, enabled = (amount.toLongOrNull() ?: 0) > 0) { Text("تسجيل الدفعة") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("إلغاء") } }
    )
}

@Composable
private fun EntityDropdown(label: String, options: List<Pair<Long, String>>, selectedId: Long, onSelect: (Long) -> Unit) {
    var expanded by remember { mutableStateOf(false) }
    val selectedLabel = options.firstOrNull { it.first == selectedId }?.second ?: "اختر $label"
    Box {
        OutlinedButton(onClick = { expanded = true }, modifier = Modifier.fillMaxWidth(), enabled = options.isNotEmpty()) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("$label: $selectedLabel", maxLines = 1)
                Text("⌄")
            }
        }
        DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
            options.forEach { option ->
                DropdownMenuItem(
                    text = { Text(option.second) },
                    onClick = { onSelect(option.first); expanded = false }
                )
            }
        }
    }
}

private fun formatYER(value: Long): String = String.format(Locale.US, "%,d ر.ي", value)

private fun formatDate(value: Long): String = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date(value))
