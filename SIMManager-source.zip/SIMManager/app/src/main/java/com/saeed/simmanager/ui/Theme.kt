package com.saeed.simmanager.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val AppLightColors = lightColorScheme(
    primary = Color(0xFF155EEF),
    onPrimary = Color.White,
    secondary = Color(0xFF0F766E),
    background = Color(0xFFF6F8FC),
    surface = Color.White,
    error = Color(0xFFB42318)
)

@Composable
fun SimManagerTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = AppLightColors,
        content = content
    )
}
