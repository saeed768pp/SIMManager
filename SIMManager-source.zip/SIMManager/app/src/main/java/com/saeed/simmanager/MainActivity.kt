package com.saeed.simmanager

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import com.saeed.simmanager.data.AppDatabase
import com.saeed.simmanager.ui.SIMManagerApp
import com.saeed.simmanager.ui.SimManagerTheme

class MainActivity : ComponentActivity() {
    private val database by lazy { AppDatabase.getInstance(applicationContext) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            SimManagerTheme {
                SIMManagerApp(database)
            }
        }
    }
}
