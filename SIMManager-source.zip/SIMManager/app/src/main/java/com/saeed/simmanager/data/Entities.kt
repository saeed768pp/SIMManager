package com.saeed.simmanager.data

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(tableName = "customers")
data class Customer(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val phone: String = "",
    val notes: String = "",
    val createdAt: Long = System.currentTimeMillis(),
    val archived: Boolean = false
)

@Entity(tableName = "telecom_providers")
data class TelecomProvider(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val active: Boolean = true
)

@Entity(
    tableName = "packages",
    foreignKeys = [ForeignKey(
        entity = TelecomProvider::class,
        parentColumns = ["id"],
        childColumns = ["providerId"],
        onDelete = ForeignKey.RESTRICT
    )],
    indices = [Index(value = ["providerId"])]
)
data class PackagePlan(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val providerId: Long,
    val name: String,
    val priceYER: Long,
    val durationDays: Int? = null,
    val active: Boolean = true
)

@Entity(
    tableName = "sim_cards",
    foreignKeys = [
        ForeignKey(entity = Customer::class, parentColumns = ["id"], childColumns = ["customerId"], onDelete = ForeignKey.RESTRICT),
        ForeignKey(entity = TelecomProvider::class, parentColumns = ["id"], childColumns = ["providerId"], onDelete = ForeignKey.RESTRICT)
    ],
    indices = [Index(value = ["customerId"]), Index(value = ["providerId"]), Index(value = ["providerId", "number"], unique = true)]
)
data class SimCard(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val customerId: Long,
    val providerId: Long,
    val number: String,
    val receivedAt: Long = System.currentTimeMillis(),
    val custodyStatus: String = "with_me", // with_me | returned
    val active: Boolean = true
)

@Entity(
    tableName = "orders",
    foreignKeys = [
        ForeignKey(entity = Customer::class, parentColumns = ["id"], childColumns = ["customerId"], onDelete = ForeignKey.RESTRICT),
        ForeignKey(entity = SimCard::class, parentColumns = ["id"], childColumns = ["simId"], onDelete = ForeignKey.RESTRICT),
        ForeignKey(entity = PackagePlan::class, parentColumns = ["id"], childColumns = ["packageId"], onDelete = ForeignKey.RESTRICT)
    ],
    indices = [Index(value = ["customerId"]), Index(value = ["simId"]), Index(value = ["packageId"]), Index(value = ["status"])]
)
data class ServiceOrder(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val customerId: Long,
    val simId: Long,
    val packageId: Long,
    val packageNameSnapshot: String,
    val priceYER: Long,
    val status: String = "new", // new | processing | completed | cancelled
    val createdAt: Long = System.currentTimeMillis(),
    val dueDate: Long? = null,
    val completedAt: Long? = null,
    val notes: String = ""
)

@Entity(
    tableName = "payments",
    foreignKeys = [ForeignKey(
        entity = ServiceOrder::class,
        parentColumns = ["id"],
        childColumns = ["orderId"],
        onDelete = ForeignKey.RESTRICT
    )],
    indices = [Index(value = ["orderId"]), Index(value = ["paidAt"])]
)
data class Payment(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val orderId: Long,
    val amountYER: Long,
    val paidAt: Long = System.currentTimeMillis(),
    val method: String = "نقدًا",
    val notes: String = ""
)

@Entity(
    tableName = "sim_handover_events",
    foreignKeys = [ForeignKey(
        entity = SimCard::class,
        parentColumns = ["id"],
        childColumns = ["simId"],
        onDelete = ForeignKey.RESTRICT
    )],
    indices = [Index(value = ["simId"])]
)
data class SimHandoverEvent(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val simId: Long,
    val action: String, // received | returned
    val eventDate: Long = System.currentTimeMillis(),
    val notes: String = ""
)

@Entity(tableName = "activity_logs", indices = [Index(value = ["createdAt"])])
data class ActivityLog(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val entityType: String,
    val entityId: Long,
    val action: String,
    val details: String = "",
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "reminders", indices = [Index(value = ["remindAt"]), Index(value = ["completed"])])
data class Reminder(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val customerId: Long? = null,
    val orderId: Long? = null,
    val reminderType: String,
    val remindAt: Long,
    val completed: Boolean = false,
    val note: String = ""
)

/** A denormalized read model used by the orders and accounts screens. */
data class OrderSummary(
    @ColumnInfo(name = "id") val id: Long,
    @ColumnInfo(name = "customerName") val customerName: String,
    @ColumnInfo(name = "simNumber") val simNumber: String,
    @ColumnInfo(name = "packageNameSnapshot") val packageName: String,
    @ColumnInfo(name = "priceYER") val priceYER: Long,
    @ColumnInfo(name = "paidYER") val paidYER: Long,
    @ColumnInfo(name = "status") val status: String,
    @ColumnInfo(name = "custodyStatus") val custodyStatus: String,
    @ColumnInfo(name = "createdAt") val createdAt: Long,
    @ColumnInfo(name = "dueDate") val dueDate: Long?
) {
    val remainingYER: Long get() = (priceYER - paidYER).coerceAtLeast(0)
}
